package com.gupta.sudhanshu.cs478.sdmp_project1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ContactEditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_edit);
    }
}
